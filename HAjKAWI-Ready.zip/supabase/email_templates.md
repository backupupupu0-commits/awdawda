# قوالب البريد (مطلوبة لرمز التحقق)

افتراضياً يرسل Supabase **رابطاً** في البريد. التطبيق يحتاج **رمزاً من 6 أرقام**، لذلك عدّل القالبين:

Supabase Dashboard → **Authentication → Emails → Templates**

## 1) Confirm signup (تأكيد التسجيل)
Subject: `رمز التحقق من حكاوي`

```html
<div dir="rtl" style="font-family:Arial,sans-serif">
  <h2>مرحباً بك في حكاوي 📖</h2>
  <p>رمز التحقق الخاص بك هو:</p>
  <h1 style="letter-spacing:6px">{{ .Token }}</h1>
  <p>أدخله في التطبيق لتفعيل حسابك. الرمز صالح لفترة قصيرة.</p>
</div>
```

## 2) Reset password (استعادة كلمة المرور)
Subject: `رمز استعادة كلمة المرور`

```html
<div dir="rtl" style="font-family:Arial,sans-serif">
  <h2>استعادة كلمة المرور</h2>
  <p>رمز الاستعادة الخاص بك هو:</p>
  <h1 style="letter-spacing:6px">{{ .Token }}</h1>
  <p>أدخله في التطبيق ثم اختر كلمة مرور جديدة. إذا لم تطلب ذلك فتجاهل الرسالة.</p>
</div>
```

المتغير `{{ .Token }}` هو الذي يضع الرمز. لا تحذفه.
