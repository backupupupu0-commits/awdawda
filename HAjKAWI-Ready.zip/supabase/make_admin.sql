-- Run AFTER you created the admin user in Supabase (Authentication -> Users -> Add user -> Create new user,
-- tick "Auto Confirm User"). Replace the email below if you used a different one.
update public.profiles set role = 'admin' where lower(email) = lower('Admin@gmail.com');

-- Check: this should return one row with role = admin
select id, email, role from public.profiles where role = 'admin';
