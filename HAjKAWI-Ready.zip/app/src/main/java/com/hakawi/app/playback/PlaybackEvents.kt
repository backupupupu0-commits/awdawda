package com.hakawi.app.playback

import kotlinx.coroutines.flow.MutableSharedFlow

/** Process-wide events from the playback service to the UI. */
object PlaybackEvents {
    /** (points added, new balance or null) */
    val pointsAwarded = MutableSharedFlow<Pair<Int, Int?>>(extraBufferCapacity = 8)
    val errors = MutableSharedFlow<String>(extraBufferCapacity = 4)
}
