package com.hakawi.app.playback

import android.net.Uri
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.hakawi.app.data.Story

const val EXTRA_ELIGIBLE = "eligible"

fun Story.toMediaItem(minRewardSec: Int): MediaItem {
    val extras = Bundle().apply {
        putBoolean(EXTRA_ELIGIBLE, rewardEligible && mediaType != "link" && durationSec >= minRewardSec)
    }
    return MediaItem.Builder()
        .setMediaId(id)
        .setUri(mediaUrl)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(narrator)
                .setArtworkUri(coverUrl?.let { Uri.parse(it) })
                .setDurationMs(durationSec * 1000L)
                .setExtras(extras)
                .setIsPlayable(true)
                .build()
        )
        .build()
}
