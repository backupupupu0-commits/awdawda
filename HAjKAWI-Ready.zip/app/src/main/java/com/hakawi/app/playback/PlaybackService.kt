package com.hakawi.app.playback

import android.app.PendingIntent
import android.content.Intent
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.hakawi.app.HakawiApp
import com.hakawi.app.data.Repo
import com.hakawi.app.data.SessionStore
import com.hakawi.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Owns the ExoPlayer + MediaSession (background playback, lock-screen / notification / Bluetooth controls).
 * It also measures REAL playing time and reports it to the server, which decides about points.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var repo: Repo
    private lateinit var store: SessionStore
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var tickerJob: Job? = null
    private var viewCountedFor: String? = null
    private var trackedId: String? = null
    private var trackedEligible = false
    private var accMs = 0L
    private var lastTickAt = 0L
    private var lastSaveAt = 0L
    private val doneIds = HashSet<String>()

    override fun onCreate() {
        super.onCreate()
        val container = (application as HakawiApp).container
        repo = container.repo
        store = container.session

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        player.addListener(listener)

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        mediaSession = MediaSession.Builder(this, player).setSessionActivity(openApp).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = mediaSession?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        tickerJob?.cancel()
        flushWatch()
        saveProgress()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        scope.cancel()
        super.onDestroy()
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                registerViewIfNew()
                startTicker()
            } else {
                tickerJob?.cancel()
                flushWatch()
                saveProgress()
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            flushWatch()
            trackedId = mediaItem?.mediaId
            trackedEligible = mediaItem?.mediaMetadata?.extras?.getBoolean(EXTRA_ELIGIBLE, false) ?: false
            accMs = 0L
            lastTickAt = SystemClock.elapsedRealtime()
            viewCountedFor = null
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                flushWatch()
                saveProgress()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            PlaybackEvents.errors.tryEmit("تعذّر تشغيل هذه القصة. تحقق من الاتصال أو من رابط الملف")
        }
    }

    private fun startTicker() {
        tickerJob?.cancel()
        lastTickAt = SystemClock.elapsedRealtime()
        tickerJob = scope.launch {
            while (isActive) {
                delay(1000)
                tick()
            }
        }
    }

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val id = player.currentMediaItem?.mediaId
        if (id != trackedId) {
            flushWatch()
            trackedId = id
            trackedEligible = player.currentMediaItem?.mediaMetadata?.extras?.getBoolean(EXTRA_ELIGIBLE, false) ?: false
            accMs = 0L
        } else if (player.isPlaying && id != null) {
            // Only real, continuous playing time counts. Seeking forward adds nothing.
            val delta = now - lastTickAt
            if (delta in 1..3000) accMs += delta
        }
        lastTickAt = now
        if (accMs >= 20_000L) flushWatch()
        if (now - lastSaveAt >= 15_000L) saveProgress()
    }

    private fun registerViewIfNew() {
        val id = player.currentMediaItem?.mediaId ?: return
        if (viewCountedFor == id) return
        viewCountedFor = id
        scope.launch(Dispatchers.IO) { runCatching { repo.registerView(id) } }
    }

    private fun flushWatch() {
        val id = trackedId ?: return
        val secs = (accMs / 1000L).toInt()
        if (secs <= 0 || !trackedEligible || id in doneIds) return
        accMs -= secs * 1000L
        scope.launch(Dispatchers.IO) {
            try {
                val r = repo.reportWatch(id, secs)
                if (r.awarded) PlaybackEvents.pointsAwarded.tryEmit(r.pointsAdded to r.balance)
                if (r.alreadyAwarded || !r.eligible) doneIds.add(id)
            } catch (e: Exception) {
                // Offline or rejected: the seconds are simply not counted.
            }
        }
    }

    private fun saveProgress() {
        lastSaveAt = SystemClock.elapsedRealtime()
        val id = player.currentMediaItem?.mediaId ?: return
        val dur = player.duration
        var pos = player.currentPosition.coerceAtLeast(0L)
        if (dur != C.TIME_UNSET && dur > 0 && pos > dur - 10_000L) pos = 0L // finished
        store.savePositionLocal(id, pos)
        if (!store.isSignedIn) return
        scope.launch(Dispatchers.IO) { runCatching { repo.saveProgress(id, pos) } }
    }
}
