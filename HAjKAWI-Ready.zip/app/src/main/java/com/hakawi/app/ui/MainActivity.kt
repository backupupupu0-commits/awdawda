package com.hakawi.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent { HakawiRoot(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** hakawi://story/<id>  or  https://<share host>/...?story=<id> */
    private fun handleIntent(i: Intent?) {
        val data = i?.data ?: return
        val id = if (data.scheme == "hakawi") data.lastPathSegment else data.getQueryParameter("story")
        if (!id.isNullOrBlank()) vm.deepLinkStory.value = id
    }
}
