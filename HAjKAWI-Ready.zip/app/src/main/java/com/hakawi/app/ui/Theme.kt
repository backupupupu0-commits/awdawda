package com.hakawi.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Navy background, elegant purple and gold accents. Store themes replace these colors. */
data class Palette(val bg: Color, val surface: Color, val primary: Color, val secondary: Color)

val DefaultPalette = Palette(
    bg = Color(0xFF0B1033),
    surface = Color(0xFF161C4A),
    primary = Color(0xFF8B5CF6),
    secondary = Color(0xFFF5C451),
)

val MutedText = Color(0xFFA9ADD6)

fun parseColor(hex: String?, fallback: Color): Color = try {
    if (hex == null) fallback else Color(android.graphics.Color.parseColor(hex))
} catch (e: Exception) {
    fallback
}

fun paletteFrom(payload: Map<String, String>?): Palette {
    if (payload == null) return DefaultPalette
    return Palette(
        bg = parseColor(payload["bg"], DefaultPalette.bg),
        surface = parseColor(payload["surface"], DefaultPalette.surface),
        primary = parseColor(payload["primary"], DefaultPalette.primary),
        secondary = parseColor(payload["secondary"], DefaultPalette.secondary),
    )
}

@Composable
fun HakawiTheme(palette: Palette, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = palette.primary,
        onPrimary = Color.White,
        secondary = palette.secondary,
        onSecondary = Color.Black,
        background = palette.bg,
        onBackground = Color.White,
        surface = palette.surface,
        onSurface = Color.White,
        surfaceVariant = palette.surface,
        onSurfaceVariant = MutedText,
        outline = Color(0xFF3A4180),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
