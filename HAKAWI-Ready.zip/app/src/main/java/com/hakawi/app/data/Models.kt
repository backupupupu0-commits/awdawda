package com.hakawi.app.data

import org.json.JSONObject

data class Profile(
    val id: String,
    val email: String,
    val displayName: String,
    val role: String,
    val points: Int,
    val banned: Boolean,
    val themeItem: String?,
    val frameItem: String?,
) {
    val isAdmin: Boolean get() = role == "admin"
}

data class Category(val id: String, val name: String, val exclusive: Boolean, val unlockItem: String?, val sort: Int)

data class Story(
    val id: String,
    val title: String,
    val narrator: String,
    val description: String,
    val durationSec: Int,
    val mediaType: String,
    val mediaUrl: String,
    val coverUrl: String?,
    val categoryId: String?,
    val categoryName: String?,
    val status: String,
    val featured: Boolean,
    val allowRepeat: Boolean,
    val rewardEligible: Boolean,
    val views: Int,
    val createdAt: String,
) {
    private val ext: String get() = mediaUrl.substringBefore('?').substringAfterLast('.', "").lowercase()
    private val videoExts = setOf("mp4", "webm", "mkv", "m3u8", "mov")
    private val audioExts = setOf("mp3", "m4a", "aac", "ogg", "wav", "flac", "opus")

    val isVideo: Boolean get() = mediaType == "video" || (mediaType == "link" && ext in videoExts)

    /** Can be played inside the app (uploaded media or a direct media link). */
    val isPlayable: Boolean
        get() = mediaUrl.isNotBlank() &&
            (mediaType == "audio" || mediaType == "video" || ext in videoExts || ext in audioExts)
}

data class StoreItem(
    val id: String,
    val title: String,
    val description: String,
    val kind: String,
    val price: Int,
    val payload: Map<String, String>,
    val active: Boolean,
    val sort: Int,
)

data class Ad(
    val id: String,
    val title: String,
    val mediaType: String,
    val mediaUrl: String?,
    val imageUrl: String?,
    val linkUrl: String?,
    val durationSec: Int,
    val skippable: Boolean,
    val skipAfterSec: Int,
    val active: Boolean,
    val impressions: Int,
)

data class LedgerEntry(val id: Long, val amount: Int, val kind: String, val note: String, val createdAt: String)
data class ProgressEntry(val storyId: String, val positionMs: Long, val updatedAt: String)

data class AdminUser(
    val id: String, val email: String, val displayName: String, val role: String,
    val points: Int, val banned: Boolean, val createdAt: String, val lastSeenAt: String,
)

data class AdminStats(
    val users: Int, val activeUsers: Int, val bannedUsers: Int, val installs: Int,
    val stories: Int, val views: Int, val pointsGiven: Int, val adImpressions: Int,
)

data class RewardConfig(val minDurationSec: Int, val points: Int, val minWatchRatio: Double, val dailyCap: Int) {
    companion object { val DEFAULT = RewardConfig(600, 5, 0.9, 50) }
}

data class WatchResult(
    val eligible: Boolean, val awarded: Boolean, val alreadyAwarded: Boolean,
    val capped: Boolean, val pointsAdded: Int, val balance: Int?,
)

fun JSONObject.toProfile() = Profile(
    id = str("id") ?: "", email = str("email") ?: "", displayName = str("display_name") ?: "",
    role = str("role") ?: "user", points = intOr("points"), banned = optBoolean("banned", false),
    themeItem = str("theme_item"), frameItem = str("frame_item"),
)

fun JSONObject.toCategory() = Category(
    id = str("id") ?: "", name = str("name") ?: "", exclusive = optBoolean("is_exclusive", false),
    unlockItem = str("unlock_item"), sort = intOr("sort"),
)

fun JSONObject.toStory() = Story(
    id = str("id") ?: "", title = str("title") ?: "", narrator = str("narrator") ?: "",
    description = str("description") ?: "", durationSec = intOr("duration_sec"),
    mediaType = str("media_type") ?: "audio", mediaUrl = str("media_url") ?: "", coverUrl = str("cover_url"),
    categoryId = str("category_id"), categoryName = optJSONObject("categories")?.str("name"),
    status = str("status") ?: "published", featured = optBoolean("is_featured", false),
    allowRepeat = optBoolean("allow_repeat", false), rewardEligible = optBoolean("reward_eligible", true),
    views = intOr("views"), createdAt = str("created_at") ?: "",
)

fun JSONObject.toStoreItem(): StoreItem {
    val payload = HashMap<String, String>()
    optJSONObject("payload")?.let { p -> p.keys().forEach { k -> payload[k] = p.optString(k) } }
    return StoreItem(
        id = str("id") ?: "", title = str("title") ?: "", description = str("description") ?: "",
        kind = str("kind") ?: "feature", price = intOr("price"), payload = payload,
        active = optBoolean("active", true), sort = intOr("sort"),
    )
}

fun JSONObject.toAd() = Ad(
    id = str("id") ?: "", title = str("title") ?: "", mediaType = str("media_type") ?: "image",
    mediaUrl = str("media_url"), imageUrl = str("image_url"), linkUrl = str("link_url"),
    durationSec = intOr("duration_sec", 10), skippable = optBoolean("skippable", true),
    skipAfterSec = intOr("skip_after_sec", 5), active = optBoolean("active", true),
    impressions = intOr("impressions"),
)

fun JSONObject.toLedger() = LedgerEntry(
    id = longOr("id"), amount = intOr("amount"), kind = str("kind") ?: "", note = str("note") ?: "",
    createdAt = str("created_at") ?: "",
)

fun JSONObject.toAdminUser() = AdminUser(
    id = str("id") ?: "", email = str("email") ?: "", displayName = str("display_name") ?: "",
    role = str("role") ?: "user", points = intOr("points"), banned = optBoolean("banned", false),
    createdAt = str("created_at") ?: "", lastSeenAt = str("last_seen_at") ?: "",
)

fun JSONObject.toStats() = AdminStats(
    users = intOr("users"), activeUsers = intOr("active_users"), bannedUsers = intOr("banned_users"),
    installs = intOr("installs"), stories = intOr("stories"), views = intOr("views"),
    pointsGiven = intOr("points_given"), adImpressions = intOr("ad_impressions"),
)

fun JSONObject.toWatchResult() = WatchResult(
    eligible = optBoolean("eligible", false), awarded = optBoolean("awarded", false),
    alreadyAwarded = optBoolean("already_awarded", false), capped = optBoolean("capped", false),
    pointsAdded = intOr("points_added"), balance = if (has("balance") && !isNull("balance")) intOr("balance") else null,
)

/** Turns server / network errors into Arabic messages for the user. */
fun Throwable.friendly(): String {
    val m = (message ?: "").lowercase()
    return when {
        this is java.net.UnknownHostException || this is java.net.SocketTimeoutException ||
            this is java.io.IOException && this !is ApiException -> "تعذّر الاتصال بالإنترنت. تحقق من الشبكة وحاول مرة أخرى"
        "anonymous sign-ins are disabled" in m || "anonymous_provider_disabled" in m ->
            "فعّل خيار Allow anonymous sign-ins من إعدادات Supabase (Authentication) ثم أعد المحاولة"
        "invalid login credentials" in m -> "البريد الإلكتروني أو كلمة المرور غير صحيحة"
        "email not confirmed" in m -> "لم يتم تأكيد بريدك الإلكتروني بعد"
        "already registered" in m || "already been registered" in m -> "هذا البريد مسجّل مسبقاً"
        "token has expired" in m || "otp_expired" in m || "invalid" in m && "token" in m ->
            "رمز التحقق غير صحيح أو منتهي الصلاحية"
        "password should be at least" in m || "weak" in m -> "كلمة المرور ضعيفة. استخدم 6 أحرف على الأقل"
        "rate limit" in m || "too many" in m || "over_email_send_rate_limit" in m ->
            "تم إرسال عدد كبير من الرسائل. انتظر قليلاً ثم حاول مجدداً"
        "insufficient points" in m -> "رصيد النقاط غير كافٍ"
        "already owned" in m -> "تملك هذه الميزة بالفعل"
        "banned" in m -> "تم حظر هذا الحساب"
        "forbidden" in m || "permission denied" in m || "row-level security" in m -> "ليست لديك صلاحية لهذا الإجراء"
        "not owned" in m -> "يجب شراء هذه الميزة أولاً"
        "jwt" in m && "expired" in m -> "انتهت الجلسة. سجّل الدخول من جديد"
        this is ApiException && (this as ApiException).status == 413 -> "حجم الملف أكبر من الحد المسموح في خطة التخزين"
        this is ApiException -> "حدث خطأ من الخادم: ${message ?: (this as ApiException).status}"
        else -> "حدث خطأ غير متوقع"
    }
}
