package com.hakawi.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hakawi.app.HakawiApp
import com.hakawi.app.data.Ad
import com.hakawi.app.data.AdminStats
import com.hakawi.app.data.AdminUser
import com.hakawi.app.data.ApiException
import com.hakawi.app.data.Category
import com.hakawi.app.data.LedgerEntry
import com.hakawi.app.data.Profile
import com.hakawi.app.data.ProgressEntry
import com.hakawi.app.data.RewardConfig
import com.hakawi.app.data.StoreItem
import com.hakawi.app.data.Story
import com.hakawi.app.data.friendly
import com.hakawi.app.playback.PlaybackEvents
import com.hakawi.app.playback.PlayerController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException

enum class Phase { LOADING, NEEDS_CONFIG, SIGNED_OUT, SIGNED_IN, BANNED }
enum class AuthStep { LOGIN, SIGNUP, VERIFY, FORGOT, RESET }
enum class UserTab { HOME, SEARCH, LIBRARY, STORE, ACCOUNT }
enum class AdminTab { STATS, STORIES, ADS, USERS, STORE }

sealed interface Screen {
    data object Tabs : Screen
    data class StoryPage(val id: String) : Screen
    data object Ledger : Screen
    data class YouTube(val query: String) : Screen
    data class AdminStoryForm(val id: String?) : Screen
    data class AdminAdForm(val id: String?) : Screen
    data class AdminItemForm(val id: String?) : Screen
    data class AdminCategoryForm(val id: String?) : Screen
    data object AdminRewards : Screen
}

data class UploadResult(val url: String, val durationSec: Int, val mime: String)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as HakawiApp).container
    val repo = container.repo
    val player = PlayerController(app)

    val phase = MutableStateFlow(Phase.LOADING)
    val bootError = MutableStateFlow<String?>(null)
    val profile = MutableStateFlow<Profile?>(null)

    val stories = MutableStateFlow<List<Story>>(emptyList())
    val storiesLoaded = MutableStateFlow(false)
    val categories = MutableStateFlow<List<Category>>(emptyList())
    val favorites = MutableStateFlow<Set<String>>(emptySet())
    val progress = MutableStateFlow<List<ProgressEntry>>(emptyList())
    val ads = MutableStateFlow<List<Ad>>(emptyList())
    val storeItems = MutableStateFlow<List<StoreItem>>(emptyList())
    val owned = MutableStateFlow<Set<String>>(emptySet())
    val reward = MutableStateFlow(RewardConfig.DEFAULT)
    val ledger = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val ledgerLoading = MutableStateFlow(false)

    // login / signup form
    val authStep = MutableStateFlow(AuthStep.LOGIN)
    val authBusy = MutableStateFlow(false)
    val authError = MutableStateFlow<String?>(null)
    val authInfo = MutableStateFlow<String?>(null)
    val pendingEmail = MutableStateFlow("")

    // navigation
    val stack = MutableStateFlow<List<Screen>>(listOf(Screen.Tabs))
    val tab = MutableStateFlow(UserTab.HOME)
    val adminTab = MutableStateFlow(AdminTab.STATS)
    val deepLinkStory = MutableStateFlow<String?>(null)
    val searchQuery = MutableStateFlow("")
    val searchCategory = MutableStateFlow<String?>(null)

    val toasts = MutableSharedFlow<String>(extraBufferCapacity = 16)

    // admin
    val adminStats = MutableStateFlow<AdminStats?>(null)
    val adminAds = MutableStateFlow<List<Ad>>(emptyList())
    val adminUsers = MutableStateFlow<List<AdminUser>>(emptyList())
    val adminUsersLoading = MutableStateFlow(false)
    val uploadProgress = MutableStateFlow<Float?>(null)
    val saving = MutableStateFlow(false)
    private var lastUserQuery = ""

    init {
        viewModelScope.launch {
            PlaybackEvents.pointsAwarded.collect { (pts, _) ->
                toast("🎉 حصلت على $pts نقاط!")
                refreshProfile()
            }
        }
        viewModelScope.launch { PlaybackEvents.errors.collect { toast(it) } }
        start()
    }

    fun toast(msg: String) { toasts.tryEmit(msg) }

    // ------------------------------------------------------------------ boot
    fun start() {
        bootError.value = null
        if (!repo.configured) {
            phase.value = Phase.NEEDS_CONFIG
            return
        }
        viewModelScope.launch { runCatching { repo.registerInstall() } }
        if (repo.hasSession) bootstrap() else startAsGuest()
    }

    private var guestTries = 0

    /** No login screen: every device silently gets its own guest account. */
    private fun startAsGuest() {
        phase.value = Phase.LOADING
        bootError.value = null
        if (++guestTries > 3) {
            bootError.value = "تعذّر تجهيز الحساب. تحقق من إعدادات Supabase ثم أعد المحاولة"
            guestTries = 0
            return
        }
        viewModelScope.launch {
            try {
                repo.guestSignIn()
                bootstrap()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                bootError.value = e.friendly()
                guestTries = 0
            }
        }
    }

    private fun bootstrap() {
        phase.value = Phase.LOADING
        bootError.value = null
        viewModelScope.launch {
            try {
                val p = repo.fetchProfile()
                profile.value = p
                if (p.banned) {
                    phase.value = Phase.BANNED
                    return@launch
                }
                if (!p.isAdmin) stories.value = repo.cachedStories()
                player.connect()
                guestTries = 0
                phase.value = Phase.SIGNED_IN
                runCatching { repo.touchLastSeen() }
                refreshAll()
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                when (e.status) {
                    401 -> signOutLocal()
                    404 -> bootError.value = "قاعدة البيانات غير مهيّأة بعد. شغّل أكواد SQL في Supabase ثم أعد المحاولة"
                    else -> bootError.value = e.friendly()
                }
            } catch (e: Exception) {
                bootError.value = e.friendly()
            }
        }
    }

    fun refreshAll() { viewModelScope.launch { loadEverything() } }

    /** Called when the app comes to the foreground. */
    fun onForeground() {
        viewModelScope.launch { runCatching { repo.touchLastSeen() } }
        refreshAll()
    }

    private suspend fun loadEverything() {
        val admin = profile.value?.isAdmin == true
        coroutineScope {
            launch { safe { val p = repo.fetchProfile(); profile.value = p; if (p.banned) phase.value = Phase.BANNED } }
            launch { safe { stories.value = repo.fetchStories(); storiesLoaded.value = true } }
            launch { safe { categories.value = repo.fetchCategories() } }
            launch { safe { storeItems.value = repo.fetchStore() } }
            launch { safe { reward.value = repo.fetchRewardConfig() } }
            if (!admin) {
                launch { safe { favorites.value = repo.fetchFavorites() } }
                launch { safe { progress.value = repo.fetchProgress() } }
                launch { safe { ads.value = repo.fetchAds() } }
                launch { safe { owned.value = repo.fetchOwned() } }
            } else {
                launch { safe { adminStats.value = repo.adminStats() } }
                launch { safe { adminAds.value = repo.adminAllAds() } }
            }
        }
    }

    private suspend fun safe(block: suspend () -> Unit) {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            if (e.status == 401 && !repo.hasSession) signOutLocal()
        } catch (e: Exception) {
            // offline: keep what we already have
        }
    }

    private fun launchSafe(block: suspend () -> Unit) = viewModelScope.launch {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            if (e.status == 401 && !repo.hasSession) signOutLocal() else toast(e.friendly())
        } catch (e: Exception) {
            toast(e.friendly())
        }
    }

    // ------------------------------------------------------------------ auth
    fun setAuthStep(s: AuthStep) {
        authStep.value = s
        authError.value = null
        authInfo.value = null
    }

    private fun runAuth(block: suspend () -> Unit) {
        authBusy.value = true
        authError.value = null
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                authError.value = e.friendly()
            } finally {
                authBusy.value = false
            }
        }
    }

    fun submitLogin(email: String, password: String) {
        val e = email.trim()
        if (e.isEmpty() || password.isEmpty()) { authError.value = "أدخل البريد الإلكتروني وكلمة المرور"; return }
        runAuth {
            try {
                repo.signIn(e, password)
                bootstrap()
            } catch (ex: ApiException) {
                if ((ex.message ?: "").lowercase().contains("email not confirmed")) {
                    pendingEmail.value = e
                    authStep.value = AuthStep.VERIFY
                    authInfo.value = "بريدك غير مؤكد بعد. أدخل الرمز المرسل إليه أو اضغط إعادة الإرسال"
                } else throw ex
            }
        }
    }

    fun submitSignUp(email: String, password: String, name: String) {
        val e = email.trim()
        when {
            name.trim().isEmpty() -> { authError.value = "أدخل اسمك"; return }
            !e.contains("@") || !e.contains(".") -> { authError.value = "أدخل بريداً إلكترونياً صحيحاً"; return }
            password.length < 6 -> { authError.value = "كلمة المرور يجب ألا تقل عن 6 أحرف"; return }
        }
        runAuth {
            if (repo.signUp(e, password, name.trim())) {
                bootstrap()
            } else {
                // Confirmation is off: just sign in with the new account.
                try {
                    repo.signIn(e, password)
                    bootstrap()
                } catch (ex: ApiException) {
                    if ((ex.message ?: "").lowercase().contains("email not confirmed")) {
                        pendingEmail.value = e
                        authStep.value = AuthStep.VERIFY
                        authInfo.value = "أرسلنا رمز التحقق إلى $e"
                    } else throw ex
                }
            }
        }
    }

    fun submitVerify(code: String) {
        if (code.trim().length < 4) { authError.value = "أدخل رمز التحقق"; return }
        runAuth {
            repo.verifySignup(pendingEmail.value, code.trim())
            bootstrap()
        }
    }

    fun resendCode() {
        runAuth {
            repo.resendSignup(pendingEmail.value)
            authInfo.value = "تم إرسال رمز جديد إلى ${pendingEmail.value}"
        }
    }

    fun submitForgot(email: String) {
        val e = email.trim()
        if (!e.contains("@")) { authError.value = "أدخل بريدك الإلكتروني"; return }
        runAuth {
            repo.requestReset(e)
            pendingEmail.value = e
            authStep.value = AuthStep.RESET
            authInfo.value = "إذا كان البريد مسجلاً فقد أرسلنا إليه رمز الاستعادة"
        }
    }

    fun submitReset(code: String, newPassword: String) {
        if (code.trim().length < 4) { authError.value = "أدخل رمز الاستعادة"; return }
        if (newPassword.length < 6) { authError.value = "كلمة المرور يجب ألا تقل عن 6 أحرف"; return }
        runAuth {
            repo.resetPassword(pendingEmail.value, code.trim(), newPassword)
            authStep.value = AuthStep.LOGIN
            authInfo.value = "تم تغيير كلمة المرور. سجّل الدخول بها الآن"
        }
    }

    val codeBusy = MutableStateFlow(false)

    /** "Welcome back" box: the typed code is verified by the server as the admin account's password. */
    fun enterWithCode(code: String) {
        val c = code.trim()
        if (c.isEmpty()) { toast("اكتب رمزك أولاً"); return }
        codeBusy.value = true
        viewModelScope.launch {
            try {
                repo.stashGuest()
                repo.adminSignIn(c)
                val p = repo.fetchProfile()
                if (!p.isAdmin) {
                    repo.restoreGuest()
                    toast("الرمز غير صحيح")
                    return@launch
                }
                player.stop()
                resetState()
                profile.value = p
                phase.value = Phase.SIGNED_IN
                refreshAll()
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                toast(if (e.status in 400..422 && e.status != 404) "الرمز غير صحيح" else e.friendly())
            } catch (e: Exception) {
                toast(e.friendly())
            } finally {
                codeBusy.value = false
            }
        }
    }

    /** Admin exit: go back to the guest account of this device. */
    fun signOut() {
        viewModelScope.launch {
            player.stop()
            val wasAdmin = profile.value?.isAdmin == true
            repo.signOut()
            resetState()
            if (wasAdmin && repo.restoreGuest()) bootstrap() else startAsGuest()
        }
    }

    private fun signOutLocal() {
        repo.clearSession()
        player.stop()
        resetState()
        startAsGuest()
    }

    private fun resetState() {
        profile.value = null
        stories.value = emptyList()
        storiesLoaded.value = false
        favorites.value = emptySet()
        progress.value = emptyList()
        ads.value = emptyList()
        owned.value = emptySet()
        adminStats.value = null
        adminUsers.value = emptyList()
        stack.value = listOf(Screen.Tabs)
        tab.value = UserTab.HOME
        adminTab.value = AdminTab.STATS
    }

    // ------------------------------------------------------------------ navigation
    fun push(s: Screen) { stack.update { it + s } }

    /** Returns true if the back press was handled. */
    fun back(): Boolean {
        if (stack.value.size > 1) {
            stack.update { it.dropLast(1) }
            return true
        }
        if (profile.value?.isAdmin != true && tab.value != UserTab.HOME && phase.value == Phase.SIGNED_IN) {
            tab.value = UserTab.HOME
            return true
        }
        return false
    }

    fun openStory(id: String) { push(Screen.StoryPage(id)) }

    fun openStoryFromLink(id: String) {
        viewModelScope.launch {
            if (stories.value.none { it.id == id }) {
                try {
                    repo.fetchStory(id)?.let { s -> stories.update { listOf(s) + it } }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    toast(e.friendly())
                }
            }
            if (stories.value.any { it.id == id }) push(Screen.StoryPage(id)) else toast("هذه القصة غير متاحة لك")
        }
    }

    fun findStory(id: String): Story? = stories.value.firstOrNull { it.id == id }

    // ------------------------------------------------------------------ content
    fun toggleFavorite(id: String) {
        val was = id in favorites.value
        favorites.update { if (was) it - id else it + id }
        viewModelScope.launch {
            try {
                if (was) repo.removeFavorite(id) else repo.addFavorite(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                favorites.update { if (was) it + id else it - id }
                toast(e.friendly())
            }
        }
    }

    fun resumePositionMs(id: String): Long {
        val local = container.session.positionLocal(id)
        if (local > 0L) return local
        return progress.value.firstOrNull { it.storyId == id }?.positionMs ?: 0L
    }

    /** An ad to show before playback (at most once every 5 minutes), or null. */
    fun adToShow(): Ad? {
        val list = ads.value
        if (list.isEmpty()) return null
        if (System.currentTimeMillis() - container.session.lastAdShownAt < 5 * 60_000L) return null
        return list.random()
    }

    fun markAdShown(ad: Ad) {
        container.session.lastAdShownAt = System.currentTimeMillis()
        viewModelScope.launch { runCatching { repo.registerAdView(ad.id) } }
    }

    fun startPlayback(story: Story) {
        if (!story.isPlayable) {
            openExternal(story.mediaUrl)
            return
        }
        if (!player.play(story, resumePositionMs(story.id), reward.value.minDurationSec)) {
            player.connect()
            toast("جارٍ تهيئة المشغل، اضغط تشغيل مرة أخرى بعد لحظات")
        }
    }

    fun openExternal(url: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(i)
        } catch (e: Exception) {
            toast("تعذّر فتح الرابط")
        }
    }

    // ------------------------------------------------------------------ points & store
    fun refreshProfile() { viewModelScope.launch { safe { profile.value = repo.fetchProfile() } } }

    fun loadLedger() {
        viewModelScope.launch {
            ledgerLoading.value = true
            safe { ledger.value = repo.fetchLedger() }
            ledgerLoading.value = false
        }
    }

    fun purchase(item: StoreItem) = launchSafe {
        repo.purchase(item.id)
        toast("تم فتح: ${item.title}")
        profile.value = repo.fetchProfile()
        owned.value = repo.fetchOwned()
        stories.value = repo.fetchStories()
    }

    fun equip(item: StoreItem) = launchSafe {
        repo.equip(item.kind, item.id)
        profile.value = repo.fetchProfile()
        toast("تم التفعيل")
    }

    fun unequip(kind: String) = launchSafe {
        repo.equip(kind, null)
        profile.value = repo.fetchProfile()
    }

    fun updateName(name: String) = launchSafe {
        repo.updateName(name.trim())
        profile.value = repo.fetchProfile()
        toast("تم حفظ الاسم")
    }

    // ------------------------------------------------------------------ admin
    fun adminRefresh() {
        viewModelScope.launch {
            safe { adminStats.value = repo.adminStats() }
            safe { adminAds.value = repo.adminAllAds() }
            safe { stories.value = repo.fetchStories(); storiesLoaded.value = true }
            safe { storeItems.value = repo.fetchStore() }
            safe { categories.value = repo.fetchCategories() }
            safe { reward.value = repo.fetchRewardConfig() }
        }
    }

    fun adminSearchUsers(query: String) {
        lastUserQuery = query
        viewModelScope.launch {
            adminUsersLoading.value = true
            try {
                adminUsers.value = repo.adminSearchUsers(query)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.friendly())
            } finally {
                adminUsersLoading.value = false
            }
        }
    }

    fun adminSave(table: String, id: String?, body: JSONObject, onDone: () -> Unit) {
        saving.value = true
        viewModelScope.launch {
            try {
                repo.adminSave(table, id, body)
                toast("تم الحفظ")
                adminRefresh()
                onDone()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.friendly())
            } finally {
                saving.value = false
            }
        }
    }

    fun adminDelete(table: String, id: String, onDone: () -> Unit = {}) = launchSafe {
        repo.adminDelete(table, id)
        toast("تم الحذف")
        adminRefresh()
        onDone()
    }

    fun adminAdjust(userId: String, amount: Int, note: String) = launchSafe {
        val nb = repo.adminAdjustPoints(userId, amount, note)
        toast("تم التنفيذ. الرصيد الجديد: $nb")
        adminUsers.value = repo.adminSearchUsers(lastUserQuery)
        adminStats.value = repo.adminStats()
    }

    fun adminBan(userId: String, banned: Boolean) = launchSafe {
        repo.adminSetBan(userId, banned)
        toast(if (banned) "تم حظر المستخدم" else "تم إلغاء الحظر")
        adminUsers.value = repo.adminSearchUsers(lastUserQuery)
    }

    fun adminSaveReward(c: RewardConfig) = launchSafe {
        repo.adminSaveReward(c)
        reward.value = c
        toast("تم حفظ إعدادات النقاط")
    }

    /** Uploads a picked file to cloud storage and reports the public URL (and duration for audio/video). */
    fun uploadFile(uri: Uri, folder: String, onResult: (UploadResult) -> Unit) {
        viewModelScope.launch {
            try {
                onResult(upload(uri, folder))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.friendly())
            }
        }
    }

    private suspend fun upload(uri: Uri, folder: String): UploadResult {
        val ctx = getApplication<Application>()
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: "application/octet-stream"
        var name = "file"
        var size = -1L
        cr.query(uri, null, null, null, null)?.use { c ->
            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = c.getColumnIndex(OpenableColumns.SIZE)
            if (c.moveToFirst()) {
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val ext = name.substringAfterLast('.', "").ifEmpty {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
        }
        uploadProgress.value = 0f
        try {
            val url = repo.upload(
                folder, ext, mime, size,
                { cr.openInputStream(uri) ?: throw IOException("cannot open file") },
            ) { uploadProgress.value = it }
            var dur = 0
            if (mime.startsWith("audio") || mime.startsWith("video")) {
                dur = withContext(Dispatchers.IO) { probeDuration(ctx, uri) }
            }
            return UploadResult(url, dur, mime)
        } finally {
            uploadProgress.value = null
        }
    }

    private fun probeDuration(ctx: Context, uri: Uri): Int = try {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            ((r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000L).toInt()
        } finally {
            r.release()
        }
    } catch (e: Exception) {
        0
    }

    override fun onCleared() { player.release() }
}
