package com.hakawi.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hakawi.app.data.RewardConfig
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private fun isoNow(): String {
    val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
    f.timeZone = TimeZone.getTimeZone("UTC")
    return f.format(Date())
}

private fun digits(s: String) = s.filter { it.isDigit() }
private val hexRegex = Regex("^#[0-9A-Fa-f]{6}$")

// ====================================================================================== ROOT
private data class AdminTabSpec(val tab: AdminTab, val label: String, val icon: ImageVector)

@Composable
fun AdminRoot(vm: AppViewModel) {
    val stack by vm.stack.collectAsStateWithLifecycle()
    val tab by vm.adminTab.collectAsStateWithLifecycle()
    LiveSync(vm)
    BackHandler(enabled = stack.size > 1 || tab != AdminTab.STATS) {
        if (!vm.back()) vm.adminTab.value = AdminTab.STATS
    }
    val top = stack.last()
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            AnimatedContent(
                targetState = top,
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                label = "admin-nav",
            ) { s ->
                when (s) {
                    is Screen.Tabs -> when (tab) {
                        AdminTab.STATS -> AdminStatsTab(vm)
                        AdminTab.STORIES -> AdminStoriesTab(vm)
                        AdminTab.ADS -> AdminAdsTab(vm)
                        AdminTab.USERS -> AdminUsersTab(vm)
                        AdminTab.STORE -> AdminStoreTab(vm)
                    }
                    is Screen.AdminStoryForm -> AdminStoryForm(vm, s.id)
                    is Screen.AdminAdForm -> AdminAdForm(vm, s.id)
                    is Screen.AdminItemForm -> AdminItemForm(vm, s.id)
                    is Screen.AdminCategoryForm -> AdminCategoryForm(vm, s.id)
                    is Screen.AdminRewards -> AdminRewardsForm(vm)
                    else -> Box(Modifier.fillMaxSize())
                }
            }
        }
        if (top is Screen.Tabs) {
            val scheme = MaterialTheme.colorScheme
            val specs = listOf(
                AdminTabSpec(AdminTab.STATS, "الإحصائيات", Icons.Rounded.Dashboard),
                AdminTabSpec(AdminTab.STORIES, "القصص", Icons.Rounded.LibraryBooks),
                AdminTabSpec(AdminTab.ADS, "الإعلانات", Icons.Rounded.Campaign),
                AdminTabSpec(AdminTab.USERS, "المستخدمون", Icons.Rounded.Group),
                AdminTabSpec(AdminTab.STORE, "المتجر", Icons.Rounded.Storefront),
            )
            NavigationBar(containerColor = scheme.surface) {
                specs.forEach { s ->
                    NavigationBarItem(
                        selected = tab == s.tab,
                        onClick = { vm.adminTab.value = s.tab },
                        icon = { Icon(s.icon, s.label) },
                        label = { Text(s.label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black, selectedTextColor = scheme.secondary,
                            indicatorColor = scheme.secondary, unselectedIconColor = MutedText, unselectedTextColor = MutedText,
                        ),
                    )
                }
            }
        }
    }
}

// ====================================================================================== STATS
@Composable
fun AdminStatsTab(vm: AppViewModel) {
    val stats by vm.adminStats.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    var confirmLogout by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.adminRefresh() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        TopBar("لوحة تحكم الأدمن") {
            IconButton(onClick = { vm.adminRefresh() }) { Icon(Icons.Rounded.Refresh, "تحديث", tint = Color.White) }
            IconButton(onClick = { confirmLogout = true }) { Icon(Icons.Rounded.Logout, "خروج", tint = Color.White) }
        }
        Text("مرحباً ${profile?.displayName ?: ""} • ${profile?.email ?: ""}", color = MutedText, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(12.dp))
        val s = stats
        if (s == null) {
            LoadingBox()
        } else {
            val cards = listOf(
                Triple("المستخدمون المسجلون", s.users, Icons.Rounded.Group),
                Triple("نشطون (آخر 7 أيام)", s.activeUsers, Icons.Rounded.TrendingUp),
                Triple("أجهزة فتحت التطبيق", s.installs, Icons.Rounded.PhoneAndroid),
                Triple("القصص المنشورة", s.stories, Icons.Rounded.LibraryBooks),
                Triple("مشاهدات القصص", s.views, Icons.Rounded.Visibility),
                Triple("النقاط الموزعة", s.pointsGiven, Icons.Rounded.Stars),
                Triple("مستخدمون محظورون", s.bannedUsers, Icons.Rounded.Block),
                Triple("مرات ظهور الإعلانات", s.adImpressions, Icons.Rounded.Campaign),
            )
            cards.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { (label, value, icon) ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                        ) {
                            Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(Modifier.height(8.dp))
                            Text("$value", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Text(label, color = MutedText, fontSize = 12.sp)
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Text(
                "ملاحظة: «أجهزة فتحت التطبيق» تعدّ الأجهزة التي شغّلت التطبيق مرة واحدة على الأقل، وليست أرقام التحميل من متجر خارجي.",
                color = MutedText, fontSize = 11.sp, modifier = Modifier.padding(16.dp),
            )
        }
    }
    if (confirmLogout) {
        ConfirmDialog("تسجيل الخروج", "هل تريد الخروج من لوحة التحكم؟", "خروج",
            onConfirm = { confirmLogout = false; vm.signOut() }, onDismiss = { confirmLogout = false })
    }
}

// ====================================================================================== STORIES
@Composable
fun AdminStoriesTab(vm: AppViewModel) {
    val stories by vm.stories.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    var deleteId by remember { mutableStateOf<String?>(null) }
    val list = remember(stories, q) {
        val n = q.trim().lowercase()
        if (n.isEmpty()) stories else stories.filter { it.title.lowercase().contains(n) || it.narrator.lowercase().contains(n) }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("إدارة القصص") {
            IconButton(onClick = { vm.push(Screen.AdminStoryForm(null)) }) { Icon(Icons.Rounded.AddCircle, "قصة جديدة", tint = MaterialTheme.colorScheme.secondary) }
        }
        HField("بحث في القصص", q, { q = it }, Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) {
            MessageBox("لا توجد قصص. اضغط + لإضافة أول قصة", "إضافة قصة") { vm.push(Screen.AdminStoryForm(null)) }
        } else {
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { s ->
                    StoryRow(s, onClick = { vm.push(Screen.AdminStoryForm(s.id)) }) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (s.status == "published") "منشورة" else "مخفية", fontSize = 11.sp,
                                color = if (s.status == "published") Color(0xFF86EFAC) else Color(0xFFFCA5A5))
                            Row {
                                IconButton(onClick = {
                                    val body = JSONObject().put("status", if (s.status == "published") "hidden" else "published").put("updated_at", isoNow())
                                    vm.adminSave("stories", s.id, body) { }
                                }) {
                                    Icon(if (s.status == "published") Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "إظهار/إخفاء", tint = Color.White)
                                }
                                IconButton(onClick = { deleteId = s.id }) { Icon(Icons.Rounded.Delete, "حذف", tint = Color(0xFFFCA5A5)) }
                            }
                        }
                    }
                }
            }
        }
    }
    deleteId?.let { id ->
        ConfirmDialog("حذف القصة", "سيتم حذف القصة نهائياً من جميع المستخدمين.", "حذف",
            onConfirm = { vm.adminDelete("stories", id); deleteId = null }, onDismiss = { deleteId = null })
    }
}

@Composable
fun AdminStoryForm(vm: AppViewModel, id: String?) {
    val stories by vm.stories.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val saving by vm.saving.collectAsStateWithLifecycle()
    val progress by vm.uploadProgress.collectAsStateWithLifecycle()
    val existing = remember(id) { stories.firstOrNull { it.id == id } }

    var title by remember(id) { mutableStateOf(existing?.title ?: "") }
    var narrator by remember(id) { mutableStateOf(existing?.narrator ?: "") }
    var description by remember(id) { mutableStateOf(existing?.description ?: "") }
    var mediaType by remember(id) { mutableStateOf(existing?.mediaType ?: "audio") }
    var mediaUrl by remember(id) { mutableStateOf(existing?.mediaUrl ?: "") }
    var coverUrl by remember(id) { mutableStateOf(existing?.coverUrl ?: "") }
    var duration by remember(id) { mutableStateOf(existing?.durationSec?.toString() ?: "") }
    var categoryId by remember(id) { mutableStateOf(existing?.categoryId) }
    var published by remember(id) { mutableStateOf((existing?.status ?: "published") == "published") }
    var featured by remember(id) { mutableStateOf(existing?.featured ?: false) }
    var allowRepeat by remember(id) { mutableStateOf(existing?.allowRepeat ?: false) }
    var rewardEligible by remember(id) { mutableStateOf(existing?.rewardEligible ?: true) }
    var confirmDelete by remember { mutableStateOf(false) }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.uploadFile(uri, if (mediaType == "video") "video" else "audio") { r ->
            mediaUrl = r.url
            if (r.durationSec > 0) duration = r.durationSec.toString()
        }
    }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.uploadFile(uri, "covers") { r -> coverUrl = r.url }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(if (id == null) "قصة جديدة" else "تعديل القصة", onBack = { vm.back() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FormSection("البيانات الأساسية") {
                HField("اسم القصة", title, { title = it })
                HField("اسم الراوي", narrator, { narrator = it })
                HField("وصف القصة", description, { description = it }, singleLine = false, minLines = 3)
            }
            FormSection("التصنيف") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Pill("بدون", selected = categoryId == null) { categoryId = null } }
                    items(categories, key = { it.id }) { c -> Pill(c.name, selected = categoryId == c.id) { categoryId = c.id } }
                }
                if (categories.isEmpty()) Text("أضف تصنيفات من تبويب المتجر ← التصنيفات", color = MutedText, fontSize = 12.sp)
            }
            FormSection("ملف القصة") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("صوتي", selected = mediaType == "audio") { mediaType = "audio" }
                    Pill("فيديو", selected = mediaType == "video") { mediaType = "video" }
                    Pill("رابط", selected = mediaType == "link") { mediaType = "link" }
                }
                if (mediaType != "link") {
                    SoftButton(
                        if (mediaType == "video") "رفع ملف فيديو" else "رفع ملف صوتي",
                        { mediaPicker.launch(if (mediaType == "video") "video/*" else "audio/*") },
                        Modifier.fillMaxWidth(), Icons.Rounded.UploadFile,
                    )
                }
                progress?.let {
                    LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.secondary)
                    Text("جارٍ الرفع... ${(it * 100).toInt()}%", color = MutedText, fontSize = 12.sp)
                }
                HField(if (mediaType == "link") "رابط القصة" else "رابط الملف (يُملأ تلقائياً بعد الرفع)", mediaUrl, { mediaUrl = it }, keyboard = KeyboardType.Uri)
                HField("المدة بالثواني", duration, { duration = digits(it) }, keyboard = KeyboardType.Number)
                if (duration.isNotBlank()) Text("المدة: ${formatDuration(duration.toIntOrNull() ?: 0)}", color = MutedText, fontSize = 12.sp)
            }
            FormSection("صورة الغلاف") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CoverImage(coverUrl.ifBlank { null }, Modifier.size(80.dp), corner = 14.dp)
                    SoftButton("رفع صورة غلاف", { coverPicker.launch("image/*") }, Modifier.weight(1f), Icons.Rounded.Image)
                }
                HField("أو رابط الصورة", coverUrl, { coverUrl = it }, keyboard = KeyboardType.Uri)
            }
            FormSection("خيارات النشر") {
                SwitchRow("منشورة (ظاهرة لجميع المستخدمين)", published, { published = it })
                SwitchRow("قصة مميزة (تظهر في قسم المميزة)", featured, { featured = it })
                SwitchRow("منح النقاط عند المشاهدة", rewardEligible, { rewardEligible = it }, "تُمنح النقاط للقصص التي مدتها 10 دقائق فأكثر")
                SwitchRow("السماح بالنقاط أكثر من مرة", allowRepeat, { allowRepeat = it }, "يمكن للمستخدم كسب النقاط من نفس القصة مجدداً")
            }
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton("حفظ ونشر", {
                    when {
                        title.isBlank() -> vm.toast("اكتب اسم القصة")
                        mediaUrl.isBlank() -> vm.toast("ارفع ملف القصة أو ضع رابطاً")
                        else -> {
                            val body = JSONObject()
                                .put("title", title.trim())
                                .put("narrator", narrator.trim())
                                .put("description", description.trim())
                                .put("duration_sec", duration.toIntOrNull() ?: 0)
                                .put("media_type", mediaType)
                                .put("media_url", mediaUrl.trim())
                                .put("cover_url", if (coverUrl.isBlank()) JSONObject.NULL else coverUrl.trim())
                                .put("category_id", categoryId ?: JSONObject.NULL)
                                .put("status", if (published) "published" else "hidden")
                                .put("is_featured", featured)
                                .put("allow_repeat", allowRepeat)
                                .put("reward_eligible", rewardEligible)
                                .put("updated_at", isoNow())
                            vm.adminSave("stories", id, body) { vm.back() }
                        }
                    }
                }, busy = saving || progress != null)
                if (id != null) SoftButton("حذف القصة", { confirmDelete = true }, Modifier.fillMaxWidth(), Icons.Rounded.Delete, danger = true)
            }
        }
    }
    if (confirmDelete && id != null) {
        ConfirmDialog("حذف القصة", "سيتم حذف القصة نهائياً.", "حذف",
            onConfirm = { confirmDelete = false; vm.adminDelete("stories", id) { vm.back() } },
            onDismiss = { confirmDelete = false })
    }
}

// ====================================================================================== ADS
@Composable
fun AdminAdsTab(vm: AppViewModel) {
    val ads by vm.adminAds.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        TopBar("إدارة الإعلانات") {
            IconButton(onClick = { vm.push(Screen.AdminAdForm(null)) }) { Icon(Icons.Rounded.AddCircle, "إعلان جديد", tint = MaterialTheme.colorScheme.secondary) }
        }
        Text("الإعلانات المفعّلة تظهر لجميع المستخدمين قبل تشغيل القصص (مرة كل 5 دقائق كحد أقصى).", color = MutedText, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
        if (ads.isEmpty()) {
            MessageBox("لا توجد إعلانات بعد", "إضافة إعلان") { vm.push(Screen.AdminAdForm(null)) }
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(ads, key = { it.id }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
                            .clickable { vm.push(Screen.AdminAdForm(a.id)) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        CoverImage(a.imageUrl ?: if (a.mediaType == "image") a.mediaUrl else null, Modifier.size(60.dp), corner = 12.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${if (a.mediaType == "video") "فيديو" else "صورة"} • ${a.durationSec} ث • ${if (a.skippable) "قابل للتخطي بعد ${a.skipAfterSec} ث" else "غير قابل للتخطي"}",
                                color = MutedText, fontSize = 12.sp,
                            )
                            Text("${a.impressions} ظهور", color = MutedText, fontSize = 11.sp)
                        }
                        Switch(
                            checked = a.active,
                            onCheckedChange = { v -> vm.adminSave("ads", a.id, JSONObject().put("active", v)) { } },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.secondary, checkedThumbColor = Color.Black),
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminAdForm(vm: AppViewModel, id: String?) {
    val ads by vm.adminAds.collectAsStateWithLifecycle()
    val saving by vm.saving.collectAsStateWithLifecycle()
    val progress by vm.uploadProgress.collectAsStateWithLifecycle()
    val existing = remember(id) { ads.firstOrNull { it.id == id } }

    var title by remember(id) { mutableStateOf(existing?.title ?: "") }
    var type by remember(id) { mutableStateOf(existing?.mediaType ?: "image") }
    var mediaUrl by remember(id) { mutableStateOf(existing?.mediaUrl ?: "") }
    var imageUrl by remember(id) { mutableStateOf(existing?.imageUrl ?: "") }
    var linkUrl by remember(id) { mutableStateOf(existing?.linkUrl ?: "") }
    var duration by remember(id) { mutableStateOf((existing?.durationSec ?: 10).toString()) }
    var skippable by remember(id) { mutableStateOf(existing?.skippable ?: true) }
    var skipAfter by remember(id) { mutableStateOf((existing?.skipAfterSec ?: 5).toString()) }
    var active by remember(id) { mutableStateOf(existing?.active ?: true) }
    var confirmDelete by remember { mutableStateOf(false) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.uploadFile(uri, "ads") { r ->
            mediaUrl = r.url
            if (r.durationSec > 0) duration = r.durationSec.toString()
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.uploadFile(uri, "ads") { r ->
            imageUrl = r.url
            if (type == "image") mediaUrl = r.url
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(if (id == null) "إعلان جديد" else "تعديل الإعلان", onBack = { vm.back() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FormSection("الإعلان") {
                HField("عنوان الإعلان", title, { title = it })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("صورة", selected = type == "image") { type = "image" }
                    Pill("فيديو", selected = type == "video") { type = "video" }
                }
                if (type == "video") {
                    SoftButton("رفع فيديو الإعلان", { videoPicker.launch("video/*") }, Modifier.fillMaxWidth(), Icons.Rounded.UploadFile)
                    HField("رابط الفيديو (يُملأ بعد الرفع)", mediaUrl, { mediaUrl = it }, keyboard = KeyboardType.Uri)
                }
                SoftButton(if (type == "video") "رفع صورة الإعلان (غلاف)" else "رفع صورة الإعلان", { imagePicker.launch("image/*") }, Modifier.fillMaxWidth(), Icons.Rounded.Image)
                progress?.let {
                    LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.secondary)
                    Text("جارٍ الرفع... ${(it * 100).toInt()}%", color = MutedText, fontSize = 12.sp)
                }
                HField("رابط الصورة", imageUrl, { imageUrl = it }, keyboard = KeyboardType.Uri)
                HField("رابط التطبيق المعلن عنه", linkUrl, { linkUrl = it }, keyboard = KeyboardType.Uri)
            }
            FormSection("العرض") {
                HField("مدة الإعلان بالثواني", duration, { duration = digits(it) }, keyboard = KeyboardType.Number)
                SwitchRow("قابل للتخطي", skippable, { skippable = it })
                if (skippable) HField("يظهر زر التخطي بعد (ثانية)", skipAfter, { skipAfter = digits(it) }, keyboard = KeyboardType.Number)
                SwitchRow("مفعّل (يظهر لجميع المستخدمين)", active, { active = it })
            }
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton("حفظ الإعلان", {
                    val mediaOk = if (type == "video") mediaUrl.isNotBlank() else (imageUrl.isNotBlank() || mediaUrl.isNotBlank())
                    when {
                        title.isBlank() -> vm.toast("اكتب عنوان الإعلان")
                        !mediaOk -> vm.toast(if (type == "video") "ارفع فيديو الإعلان" else "ارفع صورة الإعلان")
                        else -> {
                            val body = JSONObject()
                                .put("title", title.trim())
                                .put("media_type", type)
                                .put("media_url", if (mediaUrl.isBlank()) JSONObject.NULL else mediaUrl.trim())
                                .put("image_url", if (imageUrl.isBlank()) JSONObject.NULL else imageUrl.trim())
                                .put("link_url", if (linkUrl.isBlank()) JSONObject.NULL else linkUrl.trim())
                                .put("duration_sec", (duration.toIntOrNull() ?: 10).coerceAtLeast(3))
                                .put("skippable", skippable)
                                .put("skip_after_sec", skipAfter.toIntOrNull() ?: 5)
                                .put("active", active)
                            vm.adminSave("ads", id, body) { vm.back() }
                        }
                    }
                }, busy = saving || progress != null)
                if (id != null) SoftButton("حذف الإعلان", { confirmDelete = true }, Modifier.fillMaxWidth(), Icons.Rounded.Delete, danger = true)
            }
        }
    }
    if (confirmDelete && id != null) {
        ConfirmDialog("حذف الإعلان", "سيتوقف ظهور الإعلان عند الجميع.", "حذف",
            onConfirm = { confirmDelete = false; vm.adminDelete("ads", id) { vm.back() } },
            onDismiss = { confirmDelete = false })
    }
}

// ====================================================================================== USERS
@Composable
fun AdminUsersTab(vm: AppViewModel) {
    val users by vm.adminUsers.collectAsStateWithLifecycle()
    val loading by vm.adminUsersLoading.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { vm.adminSearchUsers("") }
    val selected = users.firstOrNull { it.id == selectedId }

    Column(Modifier.fillMaxSize()) {
        TopBar("إدارة المستخدمين")
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HField("بحث بالاسم أو البريد", q, { q = it }, Modifier.weight(1f))
            IconButton(onClick = { vm.adminSearchUsers(q) }) { Icon(Icons.Rounded.Search, "بحث", tint = MaterialTheme.colorScheme.secondary) }
        }
        Spacer(Modifier.height(8.dp))
        when {
            loading && users.isEmpty() -> LoadingBox()
            users.isEmpty() -> MessageBox("لا يوجد مستخدمون مطابقون")
            else -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(users, key = { it.id }) { u ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
                            .clickable { selectedId = u.id }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(u.displayName, null, 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(u.displayName.ifBlank { "—" }, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(u.email.ifBlank { "ضيف • " + u.id.take(6) }, color = MutedText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (u.banned) Text("محظور", color = Color(0xFFFCA5A5), fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                        if (u.role == "admin") Text("أدمن", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                        PointsChip(u.points)
                    }
                }
            }
        }
    }

    selected?.let { u ->
        var amount by remember(u.id) { mutableStateOf("") }
        var note by remember(u.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { selectedId = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text(u.displayName.ifBlank { u.email.ifBlank { "ضيف" } }, color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(u.email.ifBlank { "حساب ضيف" }, color = MutedText, fontSize = 12.sp)
                    Text("الرصيد الحالي: ${u.points} نقطة", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    Text("آخر نشاط: ${u.lastSeenAt.take(16).replace('T', ' ')}", color = MutedText, fontSize = 12.sp)
                    HField("عدد النقاط", amount, { amount = digits(it) }, keyboard = KeyboardType.Number)
                    HField("ملاحظة (اختياري)", note, { note = it })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SoftButton("إرسال النقاط", {
                            val n = amount.toIntOrNull() ?: 0
                            if (n <= 0) vm.toast("اكتب عدد النقاط") else { vm.adminAdjust(u.id, n, note); amount = "" }
                        }, Modifier.weight(1f), Icons.Rounded.AddCircle)
                        SoftButton("خصم", {
                            val n = amount.toIntOrNull() ?: 0
                            if (n <= 0) vm.toast("اكتب عدد النقاط") else { vm.adminAdjust(u.id, -n, note); amount = "" }
                        }, Modifier.weight(1f), Icons.Rounded.RemoveCircle, danger = true)
                    }
                    if (u.role != "admin") {
                        SoftButton(if (u.banned) "إلغاء الحظر" else "حظر المستخدم", { vm.adminBan(u.id, !u.banned) },
                            Modifier.fillMaxWidth(), Icons.Rounded.Block, danger = !u.banned)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selectedId = null }) { Text("إغلاق", color = MaterialTheme.colorScheme.secondary) } },
        )
    }
}

// ====================================================================================== STORE (items + categories + rewards)
@Composable
fun AdminStoreTab(vm: AppViewModel) {
    val items by vm.storeItems.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { TopBar("إدارة المتجر") }
        item { SoftButton("إعدادات النقاط والمكافآت", { vm.push(Screen.AdminRewards) }, Modifier.fillMaxWidth(), Icons.Rounded.Settings) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("عناصر المتجر", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.push(Screen.AdminItemForm(null)) }) { Icon(Icons.Rounded.AddCircle, "عنصر جديد", tint = MaterialTheme.colorScheme.secondary) }
            }
        }
        items(items, key = { "i" + it.id }) { it2 ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { vm.push(Screen.AdminItemForm(it2.id)) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(it2.title, color = Color.White, fontWeight = FontWeight.Bold)
                    Text(
                        "${when (it2.kind) { "theme" -> "ثيم"; "frame" -> "إطار"; "category" -> "تصنيف حصري"; else -> "ميزة" }} • ${it2.price} نقطة",
                        color = MutedText, fontSize = 12.sp,
                    )
                }
                Text(if (it2.active) "مفعّل" else "متوقف", color = if (it2.active) Color(0xFF86EFAC) else Color(0xFFFCA5A5), fontSize = 12.sp)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("التصنيفات", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.push(Screen.AdminCategoryForm(null)) }) { Icon(Icons.Rounded.AddCircle, "تصنيف جديد", tint = MaterialTheme.colorScheme.secondary) }
            }
        }
        if (categories.isEmpty()) item { Text("لا توجد تصنيفات بعد", color = MutedText, fontSize = 13.sp) }
        items(categories, key = { "c" + it.id }) { c ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { vm.push(Screen.AdminCategoryForm(c.id)) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (c.exclusive) Text("حصري 🔒", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun AdminItemForm(vm: AppViewModel, id: String?) {
    val items by vm.storeItems.collectAsStateWithLifecycle()
    val saving by vm.saving.collectAsStateWithLifecycle()
    val existing = remember(id) { items.firstOrNull { it.id == id } }

    var title by remember(id) { mutableStateOf(existing?.title ?: "") }
    var description by remember(id) { mutableStateOf(existing?.description ?: "") }
    var kind by remember(id) { mutableStateOf(existing?.kind ?: "theme") }
    var price by remember(id) { mutableStateOf((existing?.price ?: 10).toString()) }
    var active by remember(id) { mutableStateOf(existing?.active ?: true) }
    var sort by remember(id) { mutableStateOf((existing?.sort ?: 0).toString()) }
    var bg by remember(id) { mutableStateOf(existing?.payload?.get("bg") ?: "#0B1033") }
    var surface by remember(id) { mutableStateOf(existing?.payload?.get("surface") ?: "#161C4A") }
    var primary by remember(id) { mutableStateOf(existing?.payload?.get("primary") ?: "#8B5CF6") }
    var secondary by remember(id) { mutableStateOf(existing?.payload?.get("secondary") ?: "#F5C451") }
    var color1 by remember(id) { mutableStateOf(existing?.payload?.get("color") ?: "#F5C451") }
    var color2 by remember(id) { mutableStateOf(existing?.payload?.get("color2") ?: "#FDE68A") }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopBar(if (id == null) "عنصر جديد" else "تعديل العنصر", onBack = { vm.back() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FormSection("البيانات") {
                HField("اسم العنصر", title, { title = it })
                HField("الوصف", description, { description = it })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("ثيم", selected = kind == "theme") { kind = "theme" }
                    Pill("إطار", selected = kind == "frame") { kind = "frame" }
                    Pill("تصنيف حصري", selected = kind == "category") { kind = "category" }
                    Pill("ميزة", selected = kind == "feature") { kind = "feature" }
                }
                HField("السعر بالنقاط", price, { price = digits(it) }, keyboard = KeyboardType.Number)
                HField("الترتيب في المتجر", sort, { sort = digits(it) }, keyboard = KeyboardType.Number)
                SwitchRow("ظاهر في المتجر", active, { active = it })
            }
            if (kind == "theme") {
                FormSection("ألوان الثيم (صيغة #RRGGBB)") {
                    ColorField("لون الخلفية", bg) { bg = it }
                    ColorField("لون البطاقات", surface) { surface = it }
                    ColorField("اللون الأساسي", primary) { primary = it }
                    ColorField("اللون الذهبي / المميز", secondary) { secondary = it }
                }
            }
            if (kind == "frame") {
                FormSection("ألوان الإطار") {
                    ColorField("اللون الأول", color1) { color1 = it }
                    ColorField("اللون الثاني", color2) { color2 = it }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        Avatar("ح", mapOf("color" to color1, "color2" to color2), 72.dp)
                    }
                }
            }
            if (kind == "category") {
                Text("بعد حفظ هذا العنصر، اربطه بتصنيف حصري من «التصنيفات» في المتجر.", color = MutedText, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
            }
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton("حفظ", {
                    val payload = JSONObject()
                    var bad: String? = null
                    if (kind == "theme") {
                        listOf("bg" to bg, "surface" to surface, "primary" to primary, "secondary" to secondary).forEach { (k, v) ->
                            if (!hexRegex.matches(v)) bad = "لون غير صالح: $v" else payload.put(k, v)
                        }
                    }
                    if (kind == "frame") {
                        listOf("color" to color1, "color2" to color2).forEach { (k, v) ->
                            if (!hexRegex.matches(v)) bad = "لون غير صالح: $v" else payload.put(k, v)
                        }
                    }
                    when {
                        title.isBlank() -> vm.toast("اكتب اسم العنصر")
                        bad != null -> vm.toast(bad ?: "")
                        else -> {
                            val body = JSONObject()
                                .put("title", title.trim()).put("description", description.trim())
                                .put("kind", kind).put("price", price.toIntOrNull() ?: 0)
                                .put("payload", payload).put("active", active).put("sort", sort.toIntOrNull() ?: 0)
                            vm.adminSave("store_items", id, body) { vm.back() }
                        }
                    }
                }, busy = saving)
                if (id != null) SoftButton("حذف العنصر", { confirmDelete = true }, Modifier.fillMaxWidth(), Icons.Rounded.Delete, danger = true)
            }
        }
    }
    if (confirmDelete && id != null) {
        ConfirmDialog("حذف العنصر", "سيُحذف العنصر ومشتريات المستخدمين له.", "حذف",
            onConfirm = { confirmDelete = false; vm.adminDelete("store_items", id) { vm.back() } },
            onDismiss = { confirmDelete = false })
    }
}

@Composable
private fun ColorField(label: String, value: String, onChange: (String) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(parseColor(value, Color.Gray)))
        HField(label, value, { onChange(it.take(7)) }, Modifier.weight(1f))
    }
}

@Composable
fun AdminCategoryForm(vm: AppViewModel, id: String?) {
    val categories by vm.categories.collectAsStateWithLifecycle()
    val items by vm.storeItems.collectAsStateWithLifecycle()
    val saving by vm.saving.collectAsStateWithLifecycle()
    val existing = remember(id) { categories.firstOrNull { it.id == id } }

    var name by remember(id) { mutableStateOf(existing?.name ?: "") }
    var exclusive by remember(id) { mutableStateOf(existing?.exclusive ?: false) }
    var unlock by remember(id) { mutableStateOf(existing?.unlockItem) }
    var sort by remember(id) { mutableStateOf((existing?.sort ?: 0).toString()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val unlockItems = remember(items) { items.filter { it.kind == "category" } }

    Column(Modifier.fillMaxSize()) {
        TopBar(if (id == null) "تصنيف جديد" else "تعديل التصنيف", onBack = { vm.back() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FormSection("التصنيف") {
                HField("اسم التصنيف", name, { name = it })
                HField("الترتيب", sort, { sort = digits(it) }, keyboard = KeyboardType.Number)
                SwitchRow("تصنيف حصري (يُفتح بالنقاط)", exclusive, { exclusive = it })
                if (exclusive) {
                    Text("العنصر الذي يفتح هذا التصنيف:", color = MutedText, fontSize = 13.sp)
                    if (unlockItems.isEmpty()) {
                        Text("أنشئ أولاً عنصراً من نوع «تصنيف حصري» في المتجر.", color = Color(0xFFFCA5A5), fontSize = 12.sp)
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(unlockItems, key = { it.id }) { u -> Pill("${u.title} (${u.price})", selected = unlock == u.id) { unlock = u.id } }
                        }
                    }
                }
            }
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton("حفظ", {
                    when {
                        name.isBlank() -> vm.toast("اكتب اسم التصنيف")
                        exclusive && unlock == null -> vm.toast("اختر العنصر الذي يفتح هذا التصنيف")
                        else -> {
                            val body = JSONObject().put("name", name.trim()).put("is_exclusive", exclusive)
                                .put("unlock_item", if (exclusive) (unlock ?: JSONObject.NULL) else JSONObject.NULL)
                                .put("sort", sort.toIntOrNull() ?: 0)
                            vm.adminSave("categories", id, body) { vm.back() }
                        }
                    }
                }, busy = saving)
                if (id != null) SoftButton("حذف التصنيف", { confirmDelete = true }, Modifier.fillMaxWidth(), Icons.Rounded.Delete, danger = true)
            }
        }
    }
    if (confirmDelete && id != null) {
        ConfirmDialog("حذف التصنيف", "ستبقى القصص لكن بدون تصنيف.", "حذف",
            onConfirm = { confirmDelete = false; vm.adminDelete("categories", id) { vm.back() } },
            onDismiss = { confirmDelete = false })
    }
}

@Composable
fun AdminRewardsForm(vm: AppViewModel) {
    val cfg by vm.reward.collectAsStateWithLifecycle()
    var minDur by remember(cfg) { mutableStateOf(cfg.minDurationSec.toString()) }
    var points by remember(cfg) { mutableStateOf(cfg.points.toString()) }
    var ratio by remember(cfg) { mutableStateOf((cfg.minWatchRatio * 100).toInt().toString()) }
    var cap by remember(cfg) { mutableStateOf(cfg.dailyCap.toString()) }

    Column(Modifier.fillMaxSize()) {
        TopBar("إعدادات النقاط", onBack = { vm.back() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FormSection("قواعد منح النقاط") {
                HField("أقل مدة للفيديو (بالثواني)", minDur, { minDur = digits(it) }, keyboard = KeyboardType.Number)
                HField("عدد النقاط لكل مشاهدة", points, { points = digits(it) }, keyboard = KeyboardType.Number)
                HField("نسبة المشاهدة المطلوبة %", ratio, { ratio = digits(it) }, keyboard = KeyboardType.Number)
                HField("الحد الأعلى للنقاط يومياً لكل مستخدم", cap, { cap = digits(it) }, keyboard = KeyboardType.Number)
                Text("الخادم يتحقق من وقت المشاهدة الفعلي: التقديم أو القفز في الفيديو لا يمنح نقاطاً.", color = MutedText, fontSize = 12.sp)
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                PrimaryButton("حفظ الإعدادات", {
                    val r = (ratio.toIntOrNull() ?: 90).coerceIn(10, 100) / 100.0
                    vm.adminSaveReward(RewardConfig(minDur.toIntOrNull() ?: 600, points.toIntOrNull() ?: 5, r, cap.toIntOrNull() ?: 50))
                    vm.back()
                })
            }
        }
    }
}
