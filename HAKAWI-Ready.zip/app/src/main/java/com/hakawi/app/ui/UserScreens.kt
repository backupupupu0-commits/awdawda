package com.hakawi.app.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hakawi.app.BuildConfig
import com.hakawi.app.data.StoreItem
import java.net.URLEncoder

// ------------------------------------------------------------------------------------ HOME
@Composable
fun HomeScreen(vm: AppViewModel) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val stories by vm.stories.collectAsStateWithLifecycle()
    val loaded by vm.storiesLoaded.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme

    val featured = remember(stories) { stories.filter { it.featured } }
    val newest = remember(stories) { stories.sortedByDescending { it.createdAt }.take(20) }
    val popular = remember(stories) { stories.filter { it.views > 0 }.sortedByDescending { it.views }.take(20) }

    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مرحباً، ${profile?.displayName ?: ""}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("ماذا تريد أن تسمع اليوم؟", color = MutedText, fontSize = 13.sp)
                }
                PointsChip(profile?.points ?: 0) { vm.tab.value = UserTab.STORE }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(16.dp)).background(scheme.surface)
                    .clickable { vm.tab.value = UserTab.SEARCH }.padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, null, tint = MutedText)
                Spacer(Modifier.width(10.dp))
                Text("ابحث عن قصة أو راوٍ...", color = MutedText, fontSize = 14.sp)
            }
        }
        if (stories.isEmpty()) {
            item {
                if (!loaded) LoadingBox() else MessageBox("لا توجد قصص منشورة بعد. ستظهر هنا فور نشرها.", "تحديث") { vm.refreshAll() }
            }
        } else {
            if (featured.isNotEmpty()) item { StoryRail("القصص المميزة", featured, vm, 230.dp) }
            item { StoryRail("القصص الجديدة", newest, vm, 150.dp) }
            if (popular.isNotEmpty()) item { StoryRail("الأكثر مشاهدة", popular, vm, 150.dp) }
        }
    }
}

@Composable
private fun StoryRail(title: String, list: List<com.hakawi.app.data.Story>, vm: AppViewModel, cardWidth: Dp) {
    Column {
        SectionHeader(title)
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.id }) { s -> StoryCard(s, onClick = { vm.openStory(s.id) }, width = cardWidth) }
        }
    }
}

// ------------------------------------------------------------------------------------ LIBRARY
@Composable
fun LibraryScreen(vm: AppViewModel) {
    val stories by vm.stories.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()

    val continueList = remember(stories, progress) {
        progress.filter { it.positionMs > 5_000L }
            .mapNotNull { p -> stories.firstOrNull { it.id == p.storyId } }
            .take(20)
    }
    val favList = remember(stories, favorites) { stories.filter { it.id in favorites } }

    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TopBar("مكتبتي") }
        item { Text("تابع الاستماع", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        if (continueList.isEmpty()) {
            item { Text("لم تبدأ بأي قصة بعد. ابدأ الاستماع وسنحفظ مكانك تلقائياً.", color = MutedText, fontSize = 13.sp) }
        } else {
            items(continueList, key = { "c" + it.id }) { s ->
                val pos = vm.resumePositionMs(s.id)
                StoryRow(s, onClick = { vm.openStory(s.id) }) {
                    Text("${formatMs(pos)} / ${formatDuration(s.durationSec)}", color = MutedText, fontSize = 11.sp)
                }
            }
        }
        item { Spacer(Modifier.height(6.dp)) }
        item { Text("المفضلة", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        if (favList.isEmpty()) {
            item { Text("اضغط على القلب في أي قصة لإضافتها إلى مفضلتك.", color = MutedText, fontSize = 13.sp) }
        } else {
            items(favList, key = { "f" + it.id }) { s ->
                StoryRow(s, onClick = { vm.openStory(s.id) }) {
                    IconButton(onClick = { vm.toggleFavorite(s.id) }) {
                        Icon(Icons.Rounded.Favorite, "إزالة من المفضلة", tint = Color(0xFFF472B6))
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------ SEARCH
@Composable
fun SearchScreen(vm: AppViewModel) {
    var youtubeMode by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("البحث")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("قصص حكاوي", selected = !youtubeMode) { youtubeMode = false }
            Pill("بحث يوتيوب", selected = youtubeMode) { youtubeMode = true }
        }
        Spacer(Modifier.height(10.dp))
        if (youtubeMode) YouTubeSearchPane(vm) else StorySearchPane(vm)
    }
}

@Composable
private fun StorySearchPane(vm: AppViewModel) {
    val query by vm.searchQuery.collectAsStateWithLifecycle()
    val catId by vm.searchCategory.collectAsStateWithLifecycle()
    val stories by vm.stories.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val owned by vm.owned.collectAsStateWithLifecycle()

    val results = remember(stories, query, catId) {
        val q = query.trim().lowercase()
        stories.filter { s ->
            (catId == null || s.categoryId == catId) &&
                (q.isEmpty() || s.title.lowercase().contains(q) || s.narrator.lowercase().contains(q) ||
                    s.description.lowercase().contains(q))
        }
    }

    Column(Modifier.fillMaxSize()) {
        HField("ابحث عن قصة أو راوٍ", query, { vm.searchQuery.value = it }, Modifier.padding(horizontal = 16.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Pill("الكل", selected = catId == null) { vm.searchCategory.value = null } }
            items(categories, key = { it.id }) { c ->
                val locked = c.exclusive && c.unlockItem != null && c.unlockItem !in owned
                Pill((if (locked) "🔒 " else "") + c.name, selected = catId == c.id) {
                    if (locked) {
                        vm.toast("هذا التصنيف حصري. افتحه من متجر المكافآت")
                        vm.tab.value = UserTab.STORE
                    } else vm.searchCategory.value = c.id
                }
            }
        }
        if (results.isEmpty()) {
            MessageBox(if (stories.isEmpty()) "لا توجد قصص بعد" else "لا توجد نتائج مطابقة")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(results, key = { it.id }) { s -> StoryRow(s, onClick = { vm.openStory(s.id) }) }
            }
        }
    }
}

@Composable
private fun YouTubeSearchPane(vm: AppViewModel) {
    var q by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        HField("ابحث في يوتيوب عن قصص وفيديوهات", q, { q = it })
        PrimaryButton("بحث داخل التطبيق", {
            if (q.isBlank()) vm.toast("اكتب كلمة البحث أولاً") else vm.push(Screen.YouTube(q.trim()))
        })
        SoftButton("فتح النتائج في تطبيق يوتيوب", {
            if (q.isBlank()) vm.toast("اكتب كلمة البحث أولاً")
            else vm.openExternal("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q.trim(), "UTF-8"))
        }, Modifier.fillMaxWidth(), Icons.Rounded.OpenInNew)
        MessageBox("تُعرض نتائج البحث من موقع يوتيوب الرسمي نفسه، دون أي تنزيل أو واجهات برمجة مدفوعة.")
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeScreen(vm: AppViewModel, query: String) {
    val url = "https://m.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
    var web by remember { mutableStateOf<WebView?>(null) }
    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else vm.back()
    }
    DisposableEffect(Unit) { onDispose { web?.destroy() } }
    Column(Modifier.fillMaxSize()) {
        TopBar("يوتيوب: $query", onBack = { vm.back() }) {
            IconButton(onClick = { vm.openExternal(web?.url ?: url) }) {
                Icon(Icons.Rounded.OpenInNew, "فتح في يوتيوب", tint = Color.White)
            }
        }
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    webViewClient = WebViewClient()
                    loadUrl(url)
                    web = this
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        )
    }
}

// ------------------------------------------------------------------------------------ STORE
@Composable
fun StoreScreen(vm: AppViewModel) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val items by vm.storeItems.collectAsStateWithLifecycle()
    val owned by vm.owned.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<StoreItem?>(null) }

    val groups = listOf(
        "theme" to "الثيمات والألوان",
        "frame" to "إطارات الملف الشخصي",
        "category" to "تصنيفات القصص الحصرية",
        "feature" to "مزايا إضافية",
    )

    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            TopBar("متجر المكافآت") { PointsChip(profile?.points ?: 0); Spacer(Modifier.width(8.dp)) }
        }
        item { Text("اجمع النقاط بمشاهدة القصص الطويلة (10 دقائق فأكثر) ثم استبدلها بمزايا خاصة.", color = MutedText, fontSize = 13.sp) }
        if (items.isEmpty()) item { MessageBox("لا توجد عناصر في المتجر حالياً") }
        groups.forEach { (kind, title) ->
            val list = items.filter { it.kind == kind }
            if (list.isNotEmpty()) {
                item(key = "h$kind") { Text(title, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp)) }
                items(list, key = { it.id }) { it2 ->
                    StoreItemCard(vm, it2, profile?.points ?: 0, it2.id in owned || it2.price == 0,
                        equipped = it2.id == profile?.themeItem || it2.id == profile?.frameItem,
                        onBuy = { confirm = it2 })
                }
            }
        }
    }
    confirm?.let { item ->
        ConfirmDialog(
            title = "تأكيد الشراء",
            text = "ستدفع ${item.price} نقطة مقابل «${item.title}».",
            confirmLabel = "شراء",
            onConfirm = { vm.purchase(item); confirm = null },
            onDismiss = { confirm = null },
        )
    }
}

@Composable
private fun StoreItemCard(vm: AppViewModel, item: StoreItem, balance: Int, isOwned: Boolean, equipped: Boolean, onBuy: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(scheme.surface).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            when (item.kind) {
                "theme" -> Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf("bg", "primary", "secondary").forEach { k ->
                        Box(Modifier.size(14.dp, 40.dp).clip(RoundedCornerShape(5.dp)).background(parseColor(item.payload[k], Color.Gray)))
                    }
                }
                "frame" -> Avatar("ح", item.payload, 52.dp)
                "category" -> Icon(Icons.Rounded.LockOpen, null, tint = scheme.secondary, modifier = Modifier.size(32.dp))
                else -> Icon(Icons.Rounded.Stars, null, tint = scheme.secondary, modifier = Modifier.size(32.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (item.description.isNotBlank()) Text(item.description, color = MutedText, fontSize = 12.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.width(8.dp))
        when {
            isOwned && (item.kind == "theme" || item.kind == "frame") ->
                if (equipped) SoftButton("إلغاء التفعيل", { vm.unequip(item.kind) })
                else SoftButton("تفعيل", { vm.equip(item) })
            isOwned -> Text("مملوك ✓", color = scheme.secondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            else -> Box(
                Modifier.clip(RoundedCornerShape(12.dp))
                    .background(if (balance >= item.price) scheme.secondary else Color.White.copy(alpha = 0.12f))
                    .clickable {
                        if (balance >= item.price) onBuy() else vm.toast("رصيدك غير كافٍ. تحتاج ${item.price - balance} نقطة إضافية")
                    }.padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text("${item.price} نقطة", color = if (balance >= item.price) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

// ------------------------------------------------------------------------------------ ACCOUNT
@Composable
fun AccountScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val profile by vm.profile.collectAsStateWithLifecycle()
    val items by vm.storeItems.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val owned by vm.owned.collectAsStateWithLifecycle()
    var editName by remember { mutableStateOf(false) }

    val p = profile
    val frame = items.firstOrNull { it.id == p?.frameItem }?.payload
    val mine = remember(items, owned) { items.filter { it.id in owned || it.price == 0 } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        TopBar("حسابي")
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(p?.displayName ?: "", frame, 96.dp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(p?.displayName ?: "", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = { editName = true }) { Icon(Icons.Rounded.Edit, "تعديل الاسم", tint = MutedText) }
            }
            Text(p?.email?.ifBlank { null } ?: "حسابك محفوظ على هذا الجهاز", color = MutedText, fontSize = 13.sp)
        }
        FormSection("نقاطي") {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Stars, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${p?.points ?: 0} نقطة", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("${favorites.size} في المفضلة • ${progress.size} قصة بدأت بها", color = MutedText, fontSize = 12.sp)
                }
            }
            SoftButton("سجل النقاط", { vm.push(Screen.Ledger) }, Modifier.fillMaxWidth(), Icons.Rounded.History)
            SoftButton("متجر المكافآت", { vm.tab.value = UserTab.STORE }, Modifier.fillMaxWidth(), Icons.Rounded.Storefront)
        }
        val themes = mine.filter { it.kind == "theme" }
        val frames = mine.filter { it.kind == "frame" }
        if (themes.isNotEmpty() || frames.isNotEmpty()) {
            FormSection("مظهر التطبيق") {
                if (themes.isNotEmpty()) {
                    Text("الثيم", color = MutedText, fontSize = 12.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { Pill("الافتراضي", selected = p?.themeItem == null) { vm.unequip("theme") } }
                        items(themes, key = { it.id }) { t -> Pill(t.title, selected = p?.themeItem == t.id) { vm.equip(t) } }
                    }
                }
                if (frames.isNotEmpty()) {
                    Text("الإطار", color = MutedText, fontSize = 12.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { Pill("بدون", selected = p?.frameItem == null) { vm.unequip("frame") } }
                        items(frames, key = { it.id }) { f -> Pill(f.title, selected = p?.frameItem == f.id) { vm.equip(f) } }
                    }
                }
            }
        }
        FormSection("مرحباً بعودتك") {
            Text("أهلاً بك من جديد! اكتب رمزك المميز هنا لتفعيل مزايا خاصة بحسابك.", color = MutedText, fontSize = 13.sp, lineHeight = 20.sp)
            var special by remember { mutableStateOf("") }
            val busyCode by vm.codeBusy.collectAsStateWithLifecycle()
            HField("رمزك المميز", special, { special = it }, keyboard = KeyboardType.Password)
            PrimaryButton("تفعيل", { vm.enterWithCode(special) }, busy = busyCode)
        }
        FormSection("التطبيق") {
            SoftButton("مشاركة التطبيق مع الأصدقاء", {
                val base = BuildConfig.SHARE_BASE_URL
                val text = "جرّب تطبيق حكاوي للقصص الصوتية والمرئية" + if (base.isNotBlank()) "\n$base" else ""
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                ctx.startActivity(Intent.createChooser(send, "مشاركة"))
            }, Modifier.fillMaxWidth(), Icons.Rounded.Share)
            Text("حكاوي • الإصدار ${BuildConfig.VERSION_NAME}", color = MutedText, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }

    if (editName) {
        var nm by remember { mutableStateOf(p?.displayName ?: "") }
        AlertDialog(
            onDismissRequest = { editName = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("تعديل الاسم", color = Color.White) },
            text = { HField("الاسم", nm, { nm = it }) },
            confirmButton = {
                TextButton(onClick = { if (nm.isNotBlank()) vm.updateName(nm); editName = false }) {
                    Text("حفظ", color = MaterialTheme.colorScheme.secondary)
                }
            },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("إلغاء", color = MutedText) } },
        )
    }
}

@Composable
fun LedgerScreen(vm: AppViewModel) {
    val list by vm.ledger.collectAsStateWithLifecycle()
    val loading by vm.ledgerLoading.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.loadLedger() }
    Column(Modifier.fillMaxSize()) {
        TopBar("سجل النقاط", onBack = { vm.back() })
        when {
            loading && list.isEmpty() -> LoadingBox()
            list.isEmpty() -> MessageBox("لا توجد عمليات بعد. شاهد قصة طويلة لتحصل على أولى نقاطك")
            else -> LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(list, key = { it.id }) { e ->
                    val plus = e.amount >= 0
                    val label = when (e.kind) {
                        "watch" -> "مشاهدة قصة"
                        "purchase" -> "شراء من المتجر"
                        "admin_grant" -> "إضافة من الإدارة"
                        "admin_deduct" -> "خصم من الإدارة"
                        else -> e.kind
                    }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(if (plus) Icons.Rounded.AddCircle else Icons.Rounded.RemoveCircle, null,
                            tint = if (plus) Color(0xFF86EFAC) else Color(0xFFFCA5A5))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            if (e.note.isNotBlank()) Text(e.note, color = MutedText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(e.createdAt.take(16).replace('T', ' '), color = MutedText, fontSize = 11.sp)
                        }
                        Text(
                            (if (plus) "+" else "") + e.amount, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                            color = if (plus) Color(0xFF86EFAC) else Color(0xFFFCA5A5),
                        )
                    }
                }
            }
        }
    }
}
